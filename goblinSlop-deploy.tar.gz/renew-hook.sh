#!/bin/bash
# Post-renewal hook — reload nginx after certificate renewal
systemctl reload nginx || true
